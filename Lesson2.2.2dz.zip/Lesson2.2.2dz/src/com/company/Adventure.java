package com.company;

public class Adventure extends Book implements Printable{

    public Adventure(String name, int numberOfPage) {
        super.setName(name);
        super.setNumberOfPage(numberOfPage);
    }

    @Override
    public void print() {
        System.out.println("Name: " + getName() + " NumberOfPage: " + getNumberOfPage());
    }
}
