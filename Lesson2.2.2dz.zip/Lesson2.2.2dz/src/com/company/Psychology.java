package com.company;

public class Psychology extends Book implements Printable{
    public Psychology(String name, int numberOfPage) {
        super.setName(name);
        super.setNumberOfPage(numberOfPage);
    }

    @Override
    public void print() {
        System.out.println("Name: " + getName() + " NumberOfPage: " + getNumberOfPage());

    }
}
