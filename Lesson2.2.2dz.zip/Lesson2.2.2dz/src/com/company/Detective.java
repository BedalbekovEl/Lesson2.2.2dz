package com.company;

public class Detective extends Book implements Printable{
    public Detective(String name, int numberOfPage) {
        super.setName(name);
        super.setNumberOfPage(numberOfPage);
    }

    @Override
    public void print() {
        System.out.println("Name: " + getName() + " NumberOfPage: " + getNumberOfPage());
    }
}
