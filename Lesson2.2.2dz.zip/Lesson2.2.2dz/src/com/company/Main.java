package com.company;

public class Main {


    public static void main(String[] args) {
        createObject("Adventure").print();
        createObject("Detective").print();
        createObject("Psychology").print();




    }
    public static Printable createObject(String className){
        Printable printable = null;



        switch (className){

            case "Adventure":
                printable = new Adventure("Treasure island", 350);
                break;
            case "Detective":
                printable = new Detective("Sherlock Holmes", 495);
                break;
            case "Psychology":
                printable = new Psychology("People", 85);
                break;

        }


        return printable;


    }



}
